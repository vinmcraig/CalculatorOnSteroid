﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorOnSteroid_MCM
{
    public partial class frmCalculator : Form
    {

         double Result = 0;
         double currentValue = 0;
         string lastOperator="";

         bool IsvalidValue = true;

         double memoryValue = 0;

         double[] arrayMemoryValue = new double[1];

         DataTable dtHistory = new DataTable("History_Grid");

        public frmCalculator()
        {
            InitializeComponent();
        }

        private void frmCalculator_Load(object sender, EventArgs e)
        {
            lblEquation.Text = "";
            lblMemory.Focus();

          
            DataColumn dtHistoryColumn = dtHistory.Columns.Add("Hist_ID", typeof(Int32));
            dtHistoryColumn.AutoIncrement = true;
            dtHistoryColumn.AutoIncrementSeed = 1;
            dtHistoryColumn.AutoIncrementStep = 1;
            dtHistory.Columns.Add("Hist_Action", typeof(String));
            dtHistory.Columns.Add("Hist_Value", typeof(String));

        }


        private void Number_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            string number = btn.Text;

            if (number==".")
            {
                if (txtDisplay.Text.Contains('.'))
                    return;
            }

            if (!IsvalidValue)
            {
                IsvalidValue = true;
            }

            txtDisplay.Text = txtDisplay.Text == "0" ? number : txtDisplay.Text + number;

            lblEquation.Focus();

        }

        private void frmCalculator_KeyPress(object sender, KeyPressEventArgs e)
        {

            switch (e.KeyChar)
            {
                case '0':
                    btn0.PerformClick(); break;
                case '1':
                    btn1.PerformClick(); break;
                case '2':
                    btn2.PerformClick(); break;
                case '3':
                    btn3.PerformClick(); break;
                case '4':
                    btn4.PerformClick(); break;
                case '5':
                    btn5.PerformClick(); break;
                case '6':
                    btn6.PerformClick(); break;
                case '7':
                    btn7.PerformClick(); break;
                case '8':
                    btn8.PerformClick(); break;
                case '9':
                    btn9.PerformClick(); break;
                case (char)8:
                    btnDelete.PerformClick(); break;
                case (char)43:
                    cmbOperator.SelectedItem = "Add";
                    Operator("+"); break;
                case (char)45:
                    cmbOperator.SelectedItem = "Subtract";
                    Operator("-"); break;
                case (char)46:
                    btnDecimal.PerformClick(); break;
                case (char)47:
                    cmbOperator.SelectedItem = "Divide";
                    Operator("÷"); break;
                case (char)42:
                    cmbOperator.SelectedItem = "Multiply";
                    Operator("×"); break;
                case (char)61:
                    Operator("="); break;
                case (char)13:
                    Operator("="); break;
                default:
                    return;
            }
            e.Handled = true;

        }


        private void Operator(string operation)
        {

            if (IsvalidValue)
            {
                currentValue = Convert.ToDouble(txtDisplay.Text);

                switch (lastOperator)
                {

                    case "+":
                        Result = Result + currentValue;
                        dtHistory.Rows.Add(null, "Add", currentValue);
                        break;
                    case "-":
                        Result = Result - currentValue;
                        dtHistory.Rows.Add(null, "Subtract", currentValue);
                        break;
                    case "×":
                        Result = Result * currentValue;
                        dtHistory.Rows.Add(null, "Multiply", currentValue);
                        break;
                    case "÷":

                        dtHistory.Rows.Add(null, "Divide", currentValue);

                        if (currentValue == 0)
                        {
                            InvalidSetting("Cannot divide by zero");
                            break;
                        }

                        Result = Result / currentValue;
                        break;

                    default:
                        Result = currentValue;
                        dtHistory.Rows.Add(null, cmbOperator.SelectedItem.ToString(), currentValue);
                        break;
                }

                


                if (operation == "=")
                {
                    if ((lastOperator != "=") && (IsvalidValue))
                    {
                        lblEquation.Text += currentValue + "=";
                        txtDisplay.Text = Result.ToString();
                        dtHistory.Rows.Add(null, "Equals", Result.ToString());
                    }
                    else
                    {
                        dtHistory.Rows.Add(null, "Equals", "Error!");
                    }

                }
                else
                {
                    lblEquation.Text = Result + operation;
                    txtDisplay.Text = "0";

                }

                lastOperator = operation;

               

            }
        }



        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

       
        private void btnNegate_Click(object sender, EventArgs e)
        {
            if (txtDisplay.Text.StartsWith("-"))
            {
                //remove the '-' sign to make it positive
                txtDisplay.Text = txtDisplay.Text.Substring(1);
            }
            else if (!string.IsNullOrEmpty(txtDisplay.Text) && decimal.Parse(txtDisplay.Text) != 0)
            {
                //prefix the value with the '-' sign to make it negative
                txtDisplay.Text = "-" + txtDisplay.Text;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtDisplay.Text) && IsvalidValue)
            {
                int txtlength = txtDisplay.Text.Length;

                if (txtlength != 1)
                {

                    if (txtlength == 2 && Decimal.Parse(txtDisplay.Text) < 0)
                    {
                        txtDisplay.Text = "0";
                    }
                    else
                    {
                        txtDisplay.Text = txtDisplay.Text.Remove(txtlength - 1);
                    }

                    
                }
                else
                {
                    txtDisplay.Text = "0";
                }

            }
            else
            {
                btnC.PerformClick();
            }

            lblMemory.Focus();
        }


        private void btnC_Click(object sender, EventArgs e)
        {
         
            lblEquation.Text = "";
            txtDisplay.Text = "0";
            lastOperator = "";
            Result = 0;

            btn_MemoryAdd.Enabled = true;
            btn_MemoryMinus.Enabled = true;

            if (memoryValue > 0)
            {
                btn_MemoryClear.Enabled = true;
                btn_MemoryRecall.Enabled = true;
            }

            cmbOperator.Enabled = true;
            cmbOperator.SelectedIndex = -1;

            dtHistory.Rows.Add(null, "Clear", 0);

            lblMemory.Focus();

        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            if (lastOperator == "=")
            {
                btnC.PerformClick();
            }
            else
            {
                txtDisplay.Text = "0";
            }

            dtHistory.Rows.Add(null, "Clear", 0);

            lblMemory.Focus();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            btnC.PerformClick();
        }


        private void InvalidSetting(string message)
        {
            txtDisplay.Text = message;

            btn_MemoryAdd.Enabled = false;
            btn_MemoryMinus.Enabled = false;
            btn_MemoryClear.Enabled = false;
            btn_MemoryRecall.Enabled = false;
            cmbOperator.Enabled = false;
            cmbOperator.SelectedIndex = -1;

            IsvalidValue = false;
        }

        private void Memory_Click(object sender, EventArgs e)
        {
                Button btn = (Button)sender;

                string btnMemory = btn.Text;

                switch (btnMemory)
                {

                    case "MC":
                        memoryValue = 0;
                        listMemoryTrail.DataSource = null;

                        btn_MemoryClear.Enabled = false;
                        btn_MemoryRecall.Enabled = false;
                        break;

                    case "M+":
                        memoryValue += Convert.ToDouble(txtDisplay.Text);

                        arrayMemoryValue[0] = memoryValue;

                        listMemoryTrail.DataSource = null;
                        listMemoryTrail.DataSource = arrayMemoryValue;
                        listMemoryTrail.ClearSelected();

                        btn_MemoryClear.Enabled = true;
                        btn_MemoryRecall.Enabled = true;

                        break;

                    case "M-":

                        memoryValue -= Convert.ToDouble(txtDisplay.Text);

                        arrayMemoryValue[0] = memoryValue;

                        listMemoryTrail.DataSource = null;
                        listMemoryTrail.DataSource = arrayMemoryValue;
                        listMemoryTrail.ClearSelected();

                        btn_MemoryClear.Enabled = true;
                        btn_MemoryRecall.Enabled = true;

                        break;

                    case "MR":
                        txtDisplay.Text = arrayMemoryValue[0].ToString();

                        break;

                    default: return;
                }

                lblEquation.Text = "";
                lblMemory.Focus();

        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(txtDisplay.Text);
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string clipboardText = Clipboard.GetText();
            double clipboardValue = 0;
            bool isValid = double.TryParse(clipboardText, out clipboardValue);

            if (isValid)
            {
                txtDisplay.Text = clipboardValue.ToString();
            }
            else
            {
                InvalidSetting("Invalid input");
            }

           
        }

        private void cmbOperator_DropDownClosed(object sender, EventArgs e)
        {
            string selectedOperator = cmbOperator.SelectedItem.ToString();

            switch (selectedOperator)
             {
                case "Add":
                    Operator("+"); break;
                case "Subtract":
                    Operator("-"); break;
                case "Multiply":
                    Operator("×"); break;
                case "Divide":
                    Operator("÷"); break;
                default: break;
            }

        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            Operator("=");
        }

        private void exportToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var result = new StringBuilder();
            foreach (DataRow row in dtHistory.Rows)
            {
                for (int i = 0; i < dtHistory.Columns.Count; i++)
                {
                    result.Append(row[i].ToString());
                    result.Append(i == dtHistory.Columns.Count - 1 ? "\n" : ",");
                }
                result.AppendLine();
            }

            StreamWriter objWriter = new StreamWriter("D:\\CalculatorHistory.txt", true);
            objWriter.WriteLine(result.ToString());
            objWriter.Close();

            MessageBox.Show("You have successfully exported the file.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void importFromTextToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {

                OpenFileDialog fileDialogImportText = new OpenFileDialog();

                string fileName = "CalculatorHistory";

                fileDialogImportText.Title = "Select file";

                fileDialogImportText.InitialDirectory = @"D:\";

                fileDialogImportText.FileName = fileName;

                fileDialogImportText.Filter = "Text Files(*.txt)|*.txt";

                fileDialogImportText.FilterIndex = 1;

                fileDialogImportText.RestoreDirectory = true;

                if (fileDialogImportText.ShowDialog() == DialogResult.OK)
                {

                    foreach (String myfile in fileDialogImportText.FileNames)
                    {
                        string[] allLines = File.ReadAllLines(myfile);

                        // here myfile represent your selected file name
                        string line1;
                        int i = 0;
                        line1 = allLines[i];

                        while (i < allLines.Length)
                        {
                            string[] items = allLines[i].Split(new
                            char[] { ',' }); // Split parameter which divides the columns in Text File
                            if (items.Length > 1)
                            {
                                dtHistory.Rows.Add(items[0], items[1], items[2]);
                            }
                            i = i + 1;
                        }

                        dtHistory.AcceptChanges();

                    }

                    MessageBox.Show("You have successfully imported the file.", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }





    }

  
}
