﻿namespace CalculatorOnSteroid_MCM
{
    partial class frmCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.importFromTextToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.cmbOperator = new System.Windows.Forms.ComboBox();
            this.btn_MemoryClear = new System.Windows.Forms.Button();
            this.btn_MemoryAdd = new System.Windows.Forms.Button();
            this.btn_MemoryMinus = new System.Windows.Forms.Button();
            this.btn_MemoryRecall = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn4 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btnDecimal = new System.Windows.Forms.Button();
            this.btnNegate = new System.Windows.Forms.Button();
            this.btnCE = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEquals = new System.Windows.Forms.Button();
            this.lblEquation = new System.Windows.Forms.Label();
            this.listMemoryTrail = new System.Windows.Forms.ListBox();
            this.lblMemory = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.historyToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(521, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // clearToolStripMenuItem
            // 
            this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
            this.clearToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.clearToolStripMenuItem.Text = "Clear";
            this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exportToTextToolStripMenuItem,
            this.importFromTextToolStripMenuItem});
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.historyToolStripMenuItem.Text = "History";
            // 
            // exportToTextToolStripMenuItem
            // 
            this.exportToTextToolStripMenuItem.Name = "exportToTextToolStripMenuItem";
            this.exportToTextToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exportToTextToolStripMenuItem.Text = "Export to Text";
            this.exportToTextToolStripMenuItem.Click += new System.EventHandler(this.exportToTextToolStripMenuItem_Click);
            // 
            // importFromTextToolStripMenuItem
            // 
            this.importFromTextToolStripMenuItem.Name = "importFromTextToolStripMenuItem";
            this.importFromTextToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.importFromTextToolStripMenuItem.Text = "Import from Text";
            this.importFromTextToolStripMenuItem.Click += new System.EventHandler(this.importFromTextToolStripMenuItem_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.Enabled = false;
            this.txtDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDisplay.Location = new System.Drawing.Point(12, 56);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.ReadOnly = true;
            this.txtDisplay.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtDisplay.Size = new System.Drawing.Size(291, 50);
            this.txtDisplay.TabIndex = 999;
            this.txtDisplay.Text = "0";
            this.txtDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // cmbOperator
            // 
            this.cmbOperator.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbOperator.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cmbOperator.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbOperator.FormattingEnabled = true;
            this.cmbOperator.ItemHeight = 25;
            this.cmbOperator.Items.AddRange(new object[] {
            "Add",
            "Divide",
            "Multiply",
            "Subtract"});
            this.cmbOperator.Location = new System.Drawing.Point(196, 112);
            this.cmbOperator.Name = "cmbOperator";
            this.cmbOperator.Size = new System.Drawing.Size(109, 33);
            this.cmbOperator.TabIndex = 2;
            this.cmbOperator.DropDownClosed += new System.EventHandler(this.cmbOperator_DropDownClosed);
            // 
            // btn_MemoryClear
            // 
            this.btn_MemoryClear.Enabled = false;
            this.btn_MemoryClear.Location = new System.Drawing.Point(12, 112);
            this.btn_MemoryClear.Name = "btn_MemoryClear";
            this.btn_MemoryClear.Size = new System.Drawing.Size(40, 35);
            this.btn_MemoryClear.TabIndex = 3;
            this.btn_MemoryClear.Text = "MC";
            this.btn_MemoryClear.UseVisualStyleBackColor = true;
            this.btn_MemoryClear.Click += new System.EventHandler(this.Memory_Click);
            // 
            // btn_MemoryAdd
            // 
            this.btn_MemoryAdd.Location = new System.Drawing.Point(58, 112);
            this.btn_MemoryAdd.Name = "btn_MemoryAdd";
            this.btn_MemoryAdd.Size = new System.Drawing.Size(40, 35);
            this.btn_MemoryAdd.TabIndex = 4;
            this.btn_MemoryAdd.Text = "M+";
            this.btn_MemoryAdd.UseVisualStyleBackColor = true;
            this.btn_MemoryAdd.Click += new System.EventHandler(this.Memory_Click);
            // 
            // btn_MemoryMinus
            // 
            this.btn_MemoryMinus.Location = new System.Drawing.Point(104, 112);
            this.btn_MemoryMinus.Name = "btn_MemoryMinus";
            this.btn_MemoryMinus.Size = new System.Drawing.Size(40, 35);
            this.btn_MemoryMinus.TabIndex = 5;
            this.btn_MemoryMinus.Text = "M-";
            this.btn_MemoryMinus.UseVisualStyleBackColor = true;
            this.btn_MemoryMinus.Click += new System.EventHandler(this.Memory_Click);
            // 
            // btn_MemoryRecall
            // 
            this.btn_MemoryRecall.Enabled = false;
            this.btn_MemoryRecall.Location = new System.Drawing.Point(150, 112);
            this.btn_MemoryRecall.Name = "btn_MemoryRecall";
            this.btn_MemoryRecall.Size = new System.Drawing.Size(40, 35);
            this.btn_MemoryRecall.TabIndex = 6;
            this.btn_MemoryRecall.Text = "MR";
            this.btn_MemoryRecall.UseVisualStyleBackColor = true;
            this.btn_MemoryRecall.Click += new System.EventHandler(this.Memory_Click);
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(12, 263);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(69, 49);
            this.btn1.TabIndex = 7;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(87, 263);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(69, 49);
            this.btn2.TabIndex = 8;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(162, 263);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(69, 49);
            this.btn3.TabIndex = 9;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(12, 208);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(69, 49);
            this.btn4.TabIndex = 10;
            this.btn4.Text = "4";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn5
            // 
            this.btn5.Location = new System.Drawing.Point(87, 208);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(69, 49);
            this.btn5.TabIndex = 11;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn6
            // 
            this.btn6.Location = new System.Drawing.Point(162, 208);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(69, 49);
            this.btn6.TabIndex = 12;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn9
            // 
            this.btn9.Location = new System.Drawing.Point(162, 153);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(69, 49);
            this.btn9.TabIndex = 13;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn8
            // 
            this.btn8.Location = new System.Drawing.Point(87, 153);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(69, 49);
            this.btn8.TabIndex = 14;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn7
            // 
            this.btn7.Location = new System.Drawing.Point(12, 153);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(69, 49);
            this.btn7.TabIndex = 15;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.Number_Click);
            // 
            // btn0
            // 
            this.btn0.Location = new System.Drawing.Point(87, 318);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(69, 49);
            this.btn0.TabIndex = 16;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.Number_Click);
            // 
            // btnDecimal
            // 
            this.btnDecimal.Location = new System.Drawing.Point(162, 318);
            this.btnDecimal.Name = "btnDecimal";
            this.btnDecimal.Size = new System.Drawing.Size(69, 49);
            this.btnDecimal.TabIndex = 17;
            this.btnDecimal.Text = ".";
            this.btnDecimal.UseVisualStyleBackColor = true;
            this.btnDecimal.Click += new System.EventHandler(this.Number_Click);
            // 
            // btnNegate
            // 
            this.btnNegate.Location = new System.Drawing.Point(12, 318);
            this.btnNegate.Name = "btnNegate";
            this.btnNegate.Size = new System.Drawing.Size(69, 49);
            this.btnNegate.TabIndex = 18;
            this.btnNegate.Text = "+/-";
            this.btnNegate.UseVisualStyleBackColor = true;
            this.btnNegate.Click += new System.EventHandler(this.btnNegate_Click);
            // 
            // btnCE
            // 
            this.btnCE.Location = new System.Drawing.Point(237, 153);
            this.btnCE.Name = "btnCE";
            this.btnCE.Size = new System.Drawing.Size(69, 49);
            this.btnCE.TabIndex = 19;
            this.btnCE.Text = "CE";
            this.btnCE.UseVisualStyleBackColor = true;
            this.btnCE.Click += new System.EventHandler(this.btnCE_Click);
            // 
            // btnC
            // 
            this.btnC.Location = new System.Drawing.Point(237, 208);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(69, 49);
            this.btnC.TabIndex = 20;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            this.btnC.Click += new System.EventHandler(this.btnC_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(237, 263);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(69, 49);
            this.btnDelete.TabIndex = 21;
            this.btnDelete.Text = "Del";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnEquals
            // 
            this.btnEquals.Location = new System.Drawing.Point(237, 318);
            this.btnEquals.Name = "btnEquals";
            this.btnEquals.Size = new System.Drawing.Size(69, 49);
            this.btnEquals.TabIndex = 22;
            this.btnEquals.Text = "=";
            this.btnEquals.UseVisualStyleBackColor = true;
            this.btnEquals.Click += new System.EventHandler(this.btnEquals_Click);
            // 
            // lblEquation
            // 
            this.lblEquation.AutoSize = true;
            this.lblEquation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEquation.Location = new System.Drawing.Point(9, 29);
            this.lblEquation.Name = "lblEquation";
            this.lblEquation.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblEquation.Size = new System.Drawing.Size(46, 17);
            this.lblEquation.TabIndex = 1;
            this.lblEquation.Text = "label1";
            // 
            // listMemoryTrail
            // 
            this.listMemoryTrail.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listMemoryTrail.FormattingEnabled = true;
            this.listMemoryTrail.ItemHeight = 20;
            this.listMemoryTrail.Location = new System.Drawing.Point(311, 56);
            this.listMemoryTrail.Name = "listMemoryTrail";
            this.listMemoryTrail.Size = new System.Drawing.Size(194, 304);
            this.listMemoryTrail.TabIndex = 1000;
            // 
            // lblMemory
            // 
            this.lblMemory.AutoSize = true;
            this.lblMemory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMemory.Location = new System.Drawing.Point(308, 36);
            this.lblMemory.Name = "lblMemory";
            this.lblMemory.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblMemory.Size = new System.Drawing.Size(58, 17);
            this.lblMemory.TabIndex = 1001;
            this.lblMemory.Text = "Memory";
            // 
            // frmCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(521, 388);
            this.Controls.Add(this.lblMemory);
            this.Controls.Add(this.listMemoryTrail);
            this.Controls.Add(this.lblEquation);
            this.Controls.Add(this.btnEquals);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnCE);
            this.Controls.Add(this.btnNegate);
            this.Controls.Add(this.btnDecimal);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.btn4);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn_MemoryRecall);
            this.Controls.Add(this.btn_MemoryMinus);
            this.Controls.Add(this.btn_MemoryAdd);
            this.Controls.Add(this.btn_MemoryClear);
            this.Controls.Add(this.cmbOperator);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "frmCalculator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Calculator";
            this.Load += new System.EventHandler(this.frmCalculator_Load);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.frmCalculator_KeyPress);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToTextToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem importFromTextToolStripMenuItem;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.ComboBox cmbOperator;
        private System.Windows.Forms.Button btn_MemoryClear;
        private System.Windows.Forms.Button btn_MemoryAdd;
        private System.Windows.Forms.Button btn_MemoryMinus;
        private System.Windows.Forms.Button btn_MemoryRecall;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btnDecimal;
        private System.Windows.Forms.Button btnNegate;
        private System.Windows.Forms.Button btnCE;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnEquals;
        private System.Windows.Forms.Label lblEquation;
        private System.Windows.Forms.ListBox listMemoryTrail;
        private System.Windows.Forms.Label lblMemory;
    }
}

